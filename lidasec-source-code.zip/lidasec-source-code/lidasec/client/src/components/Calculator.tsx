import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calculator as CalculatorIcon, TrendingUp } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

interface CalculationResult {
  valorBruto: number;
  taxaMensal: number;
  taxaDiaria: number;
  diasAntecipacao: number;
  valorTaxas: number;
  valorLiquido: number;
  economia: number;
}

export default function Calculator() {
  const [valorRecebivel, setValorRecebivel] = useState<string>("");
  const [prazo, setPrazo] = useState<string>("30");
  const [result, setResult] = useState<CalculationResult | null>(null);

  // Taxas baseadas em média de mercado (podem ser ajustadas)
  const TAXA_MENSAL_BASE = 4.5; // 4.5% ao mês
  const TAXA_ADMINISTRATIVA = 0; // Sem taxa administrativa adicional

  const formatCurrency = (value: number): string => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value);
  };

  const parseCurrency = (value: string): number => {
    // Remove tudo exceto números e vírgula
    const cleaned = value.replace(/[^\d,]/g, "");
    // Substitui vírgula por ponto
    const normalized = cleaned.replace(",", ".");
    return parseFloat(normalized) || 0;
  };

  const handleValorChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    // Permite apenas números, vírgula e ponto
    const sanitized = value.replace(/[^\d,]/g, "");
    setValorRecebivel(sanitized);
  };

  const calcularAntecipacao = () => {
    const valor = parseCurrency(valorRecebivel);
    const dias = parseInt(prazo);

    if (!valor || valor <= 0) {
      toast.error("Por favor, insira um valor válido para o recebível.");
      return;
    }

    if (!dias || dias <= 0) {
      toast.error("Por favor, selecione um prazo válido.");
      return;
    }

    // Cálculo das taxas
    const taxaMensal = TAXA_MENSAL_BASE;
    const taxaDiaria = taxaMensal / 30;
    const taxaTotal = (taxaDiaria * dias) / 100;
    const taxaAdministrativa = TAXA_ADMINISTRATIVA / 100;

    // Valores
    const valorTaxas = valor * (taxaTotal + taxaAdministrativa);
    const valorLiquido = valor - valorTaxas;

    // Economia comparada com empréstimo tradicional (estimativa)
    const taxaEmprestimoTradicional = 0.08; // 8% ao mês
    const custoEmprestimo = valor * (taxaEmprestimoTradicional * (dias / 30));
    const economia = custoEmprestimo - valorTaxas;

    setResult({
      valorBruto: valor,
      taxaMensal,
      taxaDiaria,
      diasAntecipacao: dias,
      valorTaxas,
      valorLiquido,
      economia: Math.max(0, economia),
    });

    toast.success("Simulação calculada com sucesso!");
  };

  const handleSolicitarProposta = () => {
    if (!result) {
      toast.error("Por favor, faça uma simulação primeiro.");
      return;
    }

    // Scroll para seção de contato
    const contatoSection = document.getElementById("contato");
    if (contatoSection) {
      contatoSection.scrollIntoView({ behavior: "smooth" });
      toast.success("Role para baixo para preencher o formulário de contato!");
    }
  };

  return (
    <section className="py-20 bg-gradient-to-br from-background via-muted/30 to-background">
      <div className="container">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-4">
              <CalculatorIcon className="w-4 h-4" />
              Simulador de Securitização
            </div>
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-foreground mb-4">
              Calcule sua Securitização
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Simule quanto você pode receber securitizando seus recebíveis. Cálculo em tempo real com
              taxas transparentes.
            </p>
          </div>

        <div className="grid lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {/* Formulário de Simulação */}
          <Card className="border-2 shadow-xl">
            <CardHeader>
              <CardTitle className="text-2xl">Dados da Simulação</CardTitle>
              <CardDescription>
                Preencha os campos abaixo para calcular sua antecipação
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="valor">Valor do Recebível (R$)</Label>
                <Input
                  id="valor"
                  type="text"
                  placeholder="Ex: 50000,00"
                  value={valorRecebivel}
                  onChange={handleValorChange}
                  className="text-lg h-12"
                />
                <p className="text-xs text-muted-foreground">
                  Digite o valor total que você tem a receber
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="prazo">Prazo de Antecipação</Label>
                <Select value={prazo} onValueChange={setPrazo}>
                  <SelectTrigger className="h-12">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="15">15 dias</SelectItem>
                    <SelectItem value="30">30 dias</SelectItem>
                    <SelectItem value="45">45 dias</SelectItem>
                    <SelectItem value="60">60 dias</SelectItem>
                    <SelectItem value="90">90 dias</SelectItem>
                    <SelectItem value="120">120 dias</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground">
                  Quantos dias faltam para o vencimento do recebível
                </p>
              </div>

              <Button
                onClick={calcularAntecipacao}
                className="w-full h-12 text-lg"
                size="lg"
              >
                <CalculatorIcon className="w-5 h-5 mr-2" />
                Calcular Antecipação
              </Button>

              <div className="pt-4 border-t">
                <p className="text-xs text-muted-foreground text-center">
                  * Taxas estimadas. Valores finais podem variar conforme análise de crédito.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Resultado da Simulação */}
          <Card className="border-2 shadow-xl bg-gradient-to-br from-primary/5 to-primary/10">
            <CardHeader>
              <CardTitle className="text-2xl">Resultado da Simulação</CardTitle>
              <CardDescription>
                {result
                  ? "Confira os valores calculados"
                  : "Preencha o formulário para ver o resultado"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {result ? (
                <div className="space-y-6">
                  {/* Valor Líquido - Destaque */}
                  <div className="bg-primary text-primary-foreground p-6 rounded-xl text-center">
                    <p className="text-sm font-medium mb-2">Você Receberá</p>
                    <p className="text-4xl font-bold">{formatCurrency(result.valorLiquido)}</p>
                    <p className="text-xs mt-2 opacity-90">
                      Em até 24 horas na sua conta
                    </p>
                  </div>

                  {/* Detalhamento */}
                  <div className="space-y-4">
                    <div className="flex justify-between items-center py-2 border-b">
                      <span className="text-muted-foreground">Valor Bruto</span>
                      <span className="font-semibold">{formatCurrency(result.valorBruto)}</span>
                    </div>

                    <div className="flex justify-between items-center py-2 border-b">
                      <span className="text-muted-foreground">Prazo</span>
                      <span className="font-semibold">{result.diasAntecipacao} dias</span>
                    </div>

                    <div className="flex justify-between items-center py-2 border-b">
                      <span className="text-muted-foreground">Taxa Mensal</span>
                      <span className="font-semibold">{result.taxaMensal.toFixed(2)}%</span>
                    </div>

                    <div className="flex justify-between items-center py-2 border-b">
                      <span className="text-muted-foreground">Taxa Diária</span>
                      <span className="font-semibold">{result.taxaDiaria.toFixed(4)}%</span>
                    </div>

                    <div className="flex justify-between items-center py-2 border-b border-destructive/30">
                      <span className="text-muted-foreground">Total de Taxas</span>
                      <span className="font-semibold text-destructive">
                        - {formatCurrency(result.valorTaxas)}
                      </span>
                    </div>

                    {result.economia > 0 && (
                      <div className="bg-green-50 dark:bg-green-950 p-4 rounded-lg flex items-start gap-3">
                        <TrendingUp className="w-5 h-5 text-green-600 dark:text-green-400 mt-0.5" />
                        <div>
                          <p className="text-sm font-medium text-green-900 dark:text-green-100">
                            Economia vs. Empréstimo Tradicional
                          </p>
                          <p className="text-lg font-bold text-green-700 dark:text-green-300">
                            {formatCurrency(result.economia)}
                          </p>
                        </div>
                      </div>
                    )}
                  </div>

                  <Button
                    onClick={handleSolicitarProposta}
                    className="w-full h-12"
                    size="lg"
                    variant="default"
                  >
                    Solicitar Proposta Oficial
                  </Button>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <CalculatorIcon className="w-16 h-16 text-muted-foreground/30 mb-4" />
                  <p className="text-muted-foreground">
                    Preencha os dados ao lado para ver o resultado da simulação
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Informações Adicionais */}
        <div className="mt-12 max-w-5xl mx-auto">
          <div className="grid md:grid-cols-3 gap-6">
            <Card>
              <CardContent className="pt-6 text-center">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">⚡</span>
                </div>
                <h3 className="font-semibold mb-2">Análise de Crédito</h3>
                <p className="text-sm text-muted-foreground">
                  Análise imediata
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6 text-center">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">🚀</span>
                </div>
                <h3 className="font-semibold mb-2">Agilidade Operacional</h3>
                <p className="text-sm text-muted-foreground">
                  Processos rápidos e eficientes
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6 text-center">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">🔒</span>
                </div>
                <h3 className="font-semibold mb-2">Segurança Total</h3>
                <p className="text-sm text-muted-foreground">
                  Seus dados protegidos e confidenciais
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
