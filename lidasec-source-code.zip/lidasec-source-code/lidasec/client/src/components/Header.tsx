import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

  const navItems = [
    { label: "Home", href: "/" },
    { label: "Sobre Nós", href: "#sobre" },
    { label: "Nossa História", href: "/nossa-historia" },
    { label: "Serviços", href: "#servicos" },
    { label: "Blog", href: "/blog" },
    { label: "Contato", href: "#contato" },
  ];

  const handleNavClick = (href: string, e: React.MouseEvent<HTMLAnchorElement>) => {
    if (href.startsWith('#')) {
      e.preventDefault();
      const element = document.getElementById(href.substring(1));
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
      setIsMenuOpen(false);
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border/40 shadow-sm">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex items-center justify-between h-24">
          {/* Logo Ampliada */}
          <Link href="/">
            <div className="cursor-pointer group">
              <img 
                src="/logo-lidasec.png" 
                alt="Lidasec - Credibilidade para seu negócio" 
                className="h-16 md:h-20 w-auto transition-all duration-300 transform group-hover:scale-105 group-hover:drop-shadow-lg"
              />
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            {navItems.map((item) => (
              item.href.startsWith('/') ? (
                <Link key={item.label} href={item.href}>
                  <span className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors relative group cursor-pointer">
                    {item.label}
                    <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary transition-all duration-300 group-hover:w-full" />
                  </span>
                </Link>
              ) : (
                <a
                  key={item.label}
                  href={item.href}
                  onClick={(e) => handleNavClick(item.href, e)}
                  className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors relative group cursor-pointer"
                >
                  {item.label}
                  <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary transition-all duration-300 group-hover:w-full" />
                </a>
              )
            ))}

          </nav>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2 text-foreground hover:bg-muted rounded-lg transition-colors"
            onClick={toggleMenu}
            aria-label="Toggle menu"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-background border-b border-border shadow-xl animate-in slide-in-from-top-5">
          <div className="container mx-auto px-4 py-6 flex flex-col gap-4">
            {navItems.map((item) => (
              item.href.startsWith('/') ? (
                <Link key={item.label} href={item.href}>
                  <span
                    className="text-lg font-medium text-foreground hover:text-primary py-2 border-b border-border/50 last:border-0 block cursor-pointer"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    {item.label}
                  </span>
                </Link>
              ) : (
                <a
                  key={item.label}
                  href={item.href}
                  onClick={(e) => handleNavClick(item.href, e)}
                  className="text-lg font-medium text-foreground hover:text-primary py-2 border-b border-border/50 last:border-0 cursor-pointer block"
                >
                  {item.label}
                </a>
              )
            ))}
            <Button className="w-full mt-4 bg-primary text-primary-foreground">
              Área do Cliente
            </Button>
          </div>
        </div>
      )}
    </header>
  );
}
