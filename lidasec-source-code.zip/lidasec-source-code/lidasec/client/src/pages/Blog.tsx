import Footer from "@/components/Footer";
import Header from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { Calendar, Clock, Search, Tag } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";

export default function Blog() {
  const [searchQuery, setSearchQuery] = useState("");
  const { data: posts, isLoading } = trpc.blog.getPosts.useQuery({ limit: 12, offset: 0 });
  const { data: categories } = trpc.blog.getCategories.useQuery();
  const { data: searchResults } = trpc.blog.searchPosts.useQuery(
    { query: searchQuery },
    { enabled: searchQuery.length > 2 }
  );

  const displayPosts = searchQuery.length > 2 && searchResults ? searchResults : posts;

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="pt-24 md:pt-28">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-primary/10 via-background to-secondary/10 py-20">
          <div className="container px-4 md:px-6">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl md:text-6xl font-serif font-bold text-foreground mb-6">
                Blog Lidasec
              </h1>
              <p className="text-xl text-muted-foreground mb-10">
                Notícias, dicas financeiras e insights sobre securitização de recebíveis
              </p>

              {/* Search Bar */}
              <div className="relative max-w-xl mx-auto">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  type="text"
                  placeholder="Buscar artigos..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-12 h-14 text-lg bg-white shadow-lg border-border/50"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Categories */}
        {categories && categories.length > 0 && (
          <section className="py-8 border-b border-border">
            <div className="container px-4 md:px-6">
              <div className="flex flex-wrap gap-3 justify-center">
                <Button variant="outline" size="sm">
                  Todos
                </Button>
                {categories.map((category) => (
                  <Button key={category.id} variant="outline" size="sm">
                    {category.name}
                  </Button>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Blog Posts Grid */}
        <section className="py-16">
          <div className="container px-4 md:px-6">
            {isLoading ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {[...Array(6)].map((_, i) => (
                  <Card key={i} className="overflow-hidden animate-pulse">
                    <div className="aspect-video bg-muted" />
                    <CardContent className="p-6">
                      <div className="h-4 bg-muted rounded mb-4" />
                      <div className="h-6 bg-muted rounded mb-3" />
                      <div className="h-4 bg-muted rounded w-3/4" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : displayPosts && displayPosts.length > 0 ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {displayPosts.map((post) => (
                  <Link key={post.id} href={`/blog/${post.slug}`}>
                    <Card className="group overflow-hidden hover:shadow-xl transition-all duration-300 cursor-pointer h-full">
                      {/* Featured Image */}
                      {post.featuredImage ? (
                        <div className="aspect-video overflow-hidden bg-muted">
                          <img
                            src={post.featuredImage}
                            alt={post.title}
                            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                          />
                        </div>
                      ) : (
                        <div className="aspect-video bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center">
                          <Tag className="w-16 h-16 text-primary/40" />
                        </div>
                      )}

                      <CardContent className="p-6">
                        {/* Category */}
                        {post.category && (
                          <span className="inline-block px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-medium mb-3">
                            {post.category.name}
                          </span>
                        )}

                        {/* Title */}
                        <h3 className="text-xl font-bold text-foreground mb-3 group-hover:text-primary transition-colors line-clamp-2">
                          {post.title}
                        </h3>

                        {/* Excerpt */}
                        {post.excerpt && (
                          <p className="text-muted-foreground mb-4 line-clamp-3">
                            {post.excerpt}
                          </p>
                        )}

                        {/* Meta Info */}
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Calendar className="w-4 h-4" />
                            <span>
                              {post.publishedAt
                                ? new Date(post.publishedAt).toLocaleDateString("pt-BR")
                                : new Date(post.createdAt).toLocaleDateString("pt-BR")}
                            </span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            <span>{post.viewCount} visualizações</span>
                          </div>
                        </div>

                        {/* Tags */}
                        {post.tags && post.tags.length > 0 && (
                          <div className="flex flex-wrap gap-2 mt-4">
                            {post.tags.slice(0, 3).map((tag) => (
                              <span
                                key={tag.id}
                                className="text-xs px-2 py-1 rounded bg-muted text-muted-foreground"
                              >
                                #{tag.name}
                              </span>
                            ))}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="text-center py-20">
                <Tag className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-2xl font-bold text-foreground mb-2">Nenhum post encontrado</h3>
                <p className="text-muted-foreground">
                  {searchQuery
                    ? "Tente buscar com outros termos"
                    : "Novos artigos serão publicados em breve"}
                </p>
              </div>
            )}
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
