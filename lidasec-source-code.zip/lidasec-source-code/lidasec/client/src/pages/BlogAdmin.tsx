import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { Edit, Eye, Plus, Trash2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function BlogAdmin() {
  const { user } = useAuth();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [editingPost, setEditingPost] = useState<number | null>(null);

  const { data: posts, isLoading, refetch } = trpc.blogAdmin.getAllPosts.useQuery();
  const { data: categories } = trpc.blog.getCategories.useQuery();
  const { data: tags } = trpc.blog.getTags.useQuery();

  const deletePostMutation = trpc.blogAdmin.deletePost.useMutation({
    onSuccess: () => {
      toast.success("Post deletado com sucesso!");
      refetch();
    },
    onError: (error) => {
      toast.error(`Erro ao deletar post: ${error.message}`);
    },
  });

  const handleDeletePost = (id: number) => {
    if (confirm("Tem certeza que deseja deletar este post?")) {
      deletePostMutation.mutate({ id });
    }
  };

  if (user?.role !== "admin") {
    return (
      <DashboardLayout>
        <div className="text-center py-20">
          <h1 className="text-3xl font-bold text-foreground mb-4">Acesso Negado</h1>
          <p className="text-muted-foreground">
            Você precisa ser um administrador para acessar esta página.
          </p>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Gerenciar Blog</h1>
            <p className="text-muted-foreground">Crie e gerencie posts do blog</p>
          </div>
          <Button onClick={() => setIsCreateDialogOpen(true)} className="gap-2">
            <Plus className="w-4 h-4" />
            Novo Post
          </Button>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Total de Posts
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-foreground">{posts?.length || 0}</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Publicados
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-primary">
                {posts?.filter((p) => p.status === "published").length || 0}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Rascunhos
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-secondary">
                {posts?.filter((p) => p.status === "draft").length || 0}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Posts Table */}
        <Card>
          <CardHeader>
            <CardTitle>Todos os Posts</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-10 text-muted-foreground">Carregando...</div>
            ) : posts && posts.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left py-3 px-4 font-medium text-muted-foreground">
                        Título
                      </th>
                      <th className="text-left py-3 px-4 font-medium text-muted-foreground">
                        Categoria
                      </th>
                      <th className="text-left py-3 px-4 font-medium text-muted-foreground">
                        Status
                      </th>
                      <th className="text-left py-3 px-4 font-medium text-muted-foreground">
                        Visualizações
                      </th>
                      <th className="text-left py-3 px-4 font-medium text-muted-foreground">
                        Data
                      </th>
                      <th className="text-right py-3 px-4 font-medium text-muted-foreground">
                        Ações
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {posts.map((post) => (
                      <tr key={post.id} className="border-b border-border hover:bg-muted/50">
                        <td className="py-3 px-4 font-medium">{post.title}</td>
                        <td className="py-3 px-4 text-muted-foreground">
                          {post.category?.name || "-"}
                        </td>
                        <td className="py-3 px-4">
                          <span
                            className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${
                              post.status === "published"
                                ? "bg-primary/10 text-primary"
                                : post.status === "draft"
                                  ? "bg-secondary/10 text-secondary"
                                  : "bg-muted text-muted-foreground"
                            }`}
                          >
                            {post.status === "published"
                              ? "Publicado"
                              : post.status === "draft"
                                ? "Rascunho"
                                : "Arquivado"}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-muted-foreground">{post.viewCount}</td>
                        <td className="py-3 px-4 text-muted-foreground">
                          {new Date(post.createdAt).toLocaleDateString("pt-BR")}
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => window.open(`/blog/${post.slug}`, "_blank")}
                            >
                              <Eye className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setEditingPost(post.id)}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeletePost(post.id)}
                            >
                              <Trash2 className="w-4 h-4 text-destructive" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-10 text-muted-foreground">
                Nenhum post encontrado. Crie seu primeiro post!
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Create/Edit Post Dialog */}
      <PostEditorDialog
        isOpen={isCreateDialogOpen || editingPost !== null}
        onClose={() => {
          setIsCreateDialogOpen(false);
          setEditingPost(null);
        }}
        postId={editingPost}
        categories={categories || []}
        tags={tags || []}
        onSuccess={() => {
          refetch();
          setIsCreateDialogOpen(false);
          setEditingPost(null);
        }}
      />
    </DashboardLayout>
  );
}

interface PostEditorDialogProps {
  isOpen: boolean;
  onClose: () => void;
  postId: number | null;
  categories: any[];
  tags: any[];
  onSuccess: () => void;
}

function PostEditorDialog({
  isOpen,
  onClose,
  postId,
  categories,
  tags,
  onSuccess,
}: PostEditorDialogProps) {
  const [formData, setFormData] = useState({
    title: "",
    slug: "",
    excerpt: "",
    content: "",
    featuredImage: "",
    categoryId: "",
    status: "draft" as "draft" | "published" | "archived",
    tagIds: [] as number[],
  });

  const { data: existingPost } = trpc.blogAdmin.getPostById.useQuery(
    { id: postId! },
    { enabled: !!postId }
  );

  const createPostMutation = trpc.blogAdmin.createPost.useMutation({
    onSuccess: () => {
      toast.success("Post criado com sucesso!");
      onSuccess();
      resetForm();
    },
    onError: (error) => {
      toast.error(`Erro ao criar post: ${error.message}`);
    },
  });

  const updatePostMutation = trpc.blogAdmin.updatePost.useMutation({
    onSuccess: () => {
      toast.success("Post atualizado com sucesso!");
      onSuccess();
      resetForm();
    },
    onError: (error) => {
      toast.error(`Erro ao atualizar post: ${error.message}`);
    },
  });

  const resetForm = () => {
    setFormData({
      title: "",
      slug: "",
      excerpt: "",
      content: "",
      featuredImage: "",
      categoryId: "",
      status: "draft",
      tagIds: [],
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const payload = {
      ...formData,
      categoryId: formData.categoryId ? Number(formData.categoryId) : undefined,
      publishedAt: formData.status === "published" ? new Date() : undefined,
    };

    if (postId) {
      updatePostMutation.mutate({ id: postId, ...payload });
    } else {
      createPostMutation.mutate(payload);
    }
  };

  // Auto-generate slug from title
  const handleTitleChange = (title: string) => {
    setFormData((prev) => ({
      ...prev,
      title,
      slug: title
        .toLowerCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/(^-|-$)/g, ""),
    }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{postId ? "Editar Post" : "Novo Post"}</DialogTitle>
          <DialogDescription>
            Preencha os campos abaixo para {postId ? "atualizar" : "criar"} um post do blog.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="title">Título *</Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) => handleTitleChange(e.target.value)}
              placeholder="Digite o título do post"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="slug">Slug *</Label>
            <Input
              id="slug"
              value={formData.slug}
              onChange={(e) => setFormData((prev) => ({ ...prev, slug: e.target.value }))}
              placeholder="url-amigavel-do-post"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="excerpt">Resumo</Label>
            <Textarea
              id="excerpt"
              value={formData.excerpt}
              onChange={(e) => setFormData((prev) => ({ ...prev, excerpt: e.target.value }))}
              placeholder="Breve resumo do post"
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="content">Conteúdo * (Markdown)</Label>
            <Textarea
              id="content"
              value={formData.content}
              onChange={(e) => setFormData((prev) => ({ ...prev, content: e.target.value }))}
              placeholder="Escreva o conteúdo em Markdown..."
              rows={10}
              required
            />
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="category">Categoria</Label>
              <Select
                value={formData.categoryId}
                onValueChange={(value) =>
                  setFormData((prev) => ({ ...prev, categoryId: value }))
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione uma categoria" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((cat) => (
                    <SelectItem key={cat.id} value={String(cat.id)}>
                      {cat.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">Status *</Label>
              <Select
                value={formData.status}
                onValueChange={(value: any) => setFormData((prev) => ({ ...prev, status: value }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="draft">Rascunho</SelectItem>
                  <SelectItem value="published">Publicado</SelectItem>
                  <SelectItem value="archived">Arquivado</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="featuredImage">URL da Imagem Destacada</Label>
            <Input
              id="featuredImage"
              value={formData.featuredImage}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, featuredImage: e.target.value }))
              }
              placeholder="https://exemplo.com/imagem.jpg"
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button
              type="submit"
              disabled={createPostMutation.isPending || updatePostMutation.isPending}
            >
              {createPostMutation.isPending || updatePostMutation.isPending
                ? "Salvando..."
                : postId
                  ? "Atualizar"
                  : "Criar Post"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
