import Footer from "@/components/Footer";
import Header from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Calendar, Clock, Tag, User } from "lucide-react";
import { Link, useParams } from "wouter";
import { Streamdown } from "streamdown";

export default function BlogPost() {
  const { slug } = useParams<{ slug: string }>();
  const { data: post, isLoading, error } = trpc.blog.getPostBySlug.useQuery(
    { slug: slug! },
    { enabled: !!slug }
  );

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="pt-24 md:pt-28 pb-20">
          <div className="container px-4 md:px-6 max-w-4xl mx-auto">
            <div className="animate-pulse space-y-6">
              <div className="h-8 bg-muted rounded w-3/4" />
              <div className="h-4 bg-muted rounded w-1/2" />
              <div className="aspect-video bg-muted rounded-2xl" />
              <div className="space-y-3">
                <div className="h-4 bg-muted rounded" />
                <div className="h-4 bg-muted rounded" />
                <div className="h-4 bg-muted rounded w-5/6" />
              </div>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (error || !post) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="pt-24 md:pt-28 pb-20">
          <div className="container px-4 md:px-6 max-w-4xl mx-auto text-center py-20">
            <Tag className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            <h1 className="text-3xl font-bold text-foreground mb-4">Post não encontrado</h1>
            <p className="text-muted-foreground mb-8">
              O artigo que você está procurando não existe ou foi removido.
            </p>
            <Link href="/blog">
              <Button>Voltar ao Blog</Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="pt-24 md:pt-28 pb-20">
        <article className="container px-4 md:px-6 max-w-4xl mx-auto">
          {/* Breadcrumb */}
          <nav className="mb-8 text-sm text-muted-foreground">
            <Link href="/" className="hover:text-primary">
              Home
            </Link>
            <span className="mx-2">/</span>
            <Link href="/blog" className="hover:text-primary">
              Blog
            </Link>
            <span className="mx-2">/</span>
            <span className="text-foreground">{post.title}</span>
          </nav>

          {/* Category Badge */}
          {post.category && (
            <div className="mb-6">
              <span className="inline-block px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium">
                {post.category.name}
              </span>
            </div>
          )}

          {/* Title */}
          <h1 className="text-4xl md:text-5xl font-serif font-bold text-foreground mb-6 leading-tight">
            {post.title}
          </h1>

          {/* Meta Info */}
          <div className="flex flex-wrap items-center gap-6 text-muted-foreground mb-10 pb-6 border-b border-border">
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              <span>
                {post.publishedAt
                  ? new Date(post.publishedAt).toLocaleDateString("pt-BR", {
                      day: "numeric",
                      month: "long",
                      year: "numeric",
                    })
                  : new Date(post.createdAt).toLocaleDateString("pt-BR", {
                      day: "numeric",
                      month: "long",
                      year: "numeric",
                    })}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5" />
              <span>{post.viewCount} visualizações</span>
            </div>
            {post.authorName && (
              <div className="flex items-center gap-2">
                <User className="w-5 h-5" />
                <span>{post.authorName}</span>
              </div>
            )}
          </div>

          {/* Featured Image */}
          {post.featuredImage && (
            <div className="mb-12 rounded-2xl overflow-hidden shadow-2xl">
              <img
                src={post.featuredImage}
                alt={post.title}
                className="w-full object-cover"
              />
            </div>
          )}

          {/* Excerpt */}
          {post.excerpt && (
            <div className="mb-10 p-6 bg-muted/50 border-l-4 border-primary rounded-r-xl">
              <p className="text-lg text-foreground italic">{post.excerpt}</p>
            </div>
          )}

          {/* Content */}
          <div className="prose prose-lg max-w-none mb-12">
            <Streamdown>{post.content}</Streamdown>
          </div>

          {/* Tags */}
          {post.tags && post.tags.length > 0 && (
            <div className="mb-12">
              <h3 className="text-lg font-bold text-foreground mb-4">Tags</h3>
              <div className="flex flex-wrap gap-3">
                {post.tags.map((tag) => (
                  <span
                    key={tag.id}
                    className="px-4 py-2 rounded-lg bg-muted text-foreground hover:bg-primary hover:text-white transition-colors cursor-pointer"
                  >
                    #{tag.name}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Share & Back */}
          <div className="flex flex-col sm:flex-row gap-4 justify-between items-center pt-8 border-t border-border">
            <Link href="/blog">
              <Button variant="outline">← Voltar ao Blog</Button>
            </Link>
            <div className="flex gap-3">
              <Button variant="outline" size="sm">
                Compartilhar
              </Button>
            </div>
          </div>
        </article>

        {/* Related Posts */}
        {post.categoryId && (
          <section className="mt-20 bg-muted/30 py-16">
            <div className="container px-4 md:px-6 max-w-6xl mx-auto">
              <h2 className="text-3xl font-serif font-bold text-foreground mb-10 text-center">
                Artigos Relacionados
              </h2>
              <RelatedPosts categoryId={post.categoryId} currentPostId={post.id} />
            </div>
          </section>
        )}
      </main>

      <Footer />
    </div>
  );
}

function RelatedPosts({ categoryId, currentPostId }: { categoryId: number; currentPostId: number }) {
  const { data: relatedPosts } = trpc.blog.getPostsByCategory.useQuery({
    categoryId,
    limit: 3,
  });

  const filteredPosts = relatedPosts?.filter((p) => p.id !== currentPostId).slice(0, 3);

  if (!filteredPosts || filteredPosts.length === 0) {
    return null;
  }

  return (
    <div className="grid md:grid-cols-3 gap-8">
      {filteredPosts.map((post) => (
        <Link key={post.id} href={`/blog/${post.slug}`}>
          <Card className="group overflow-hidden hover:shadow-xl transition-all duration-300 cursor-pointer h-full">
            {post.featuredImage ? (
              <div className="aspect-video overflow-hidden bg-muted">
                <img
                  src={post.featuredImage}
                  alt={post.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
              </div>
            ) : (
              <div className="aspect-video bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center">
                <Tag className="w-12 h-12 text-primary/40" />
              </div>
            )}

            <CardContent className="p-6">
              <h3 className="text-lg font-bold text-foreground mb-2 group-hover:text-primary transition-colors line-clamp-2">
                {post.title}
              </h3>
              {post.excerpt && (
                <p className="text-sm text-muted-foreground line-clamp-2">{post.excerpt}</p>
              )}
            </CardContent>
          </Card>
        </Link>
      ))}
    </div>
  );
}
