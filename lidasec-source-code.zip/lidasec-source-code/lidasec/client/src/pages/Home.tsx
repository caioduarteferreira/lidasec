import Footer from "@/components/Footer";
import Header from "@/components/Header";
import Calculator from "@/components/Calculator";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ArrowRight, BarChart3, CheckCircle2, Globe2, ShieldCheck, TrendingUp, Users } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { useState } from "react";

export default function Home() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });
  
  const contactMutation = trpc.contact.send.useMutation({
    onSuccess: () => {
      toast.success("Mensagem enviada com sucesso! Entraremos em contato em breve.");
      setFormData({ name: "", email: "", phone: "", message: "" });
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao enviar mensagem. Tente novamente.");
    },
  });
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    contactMutation.mutate(formData);
  };
  
  return (
    <div className="min-h-screen bg-background font-sans text-foreground overflow-x-hidden">
      <Header />

      <main className="pt-24 md:pt-28">
        {/* Hero Section */}
        <section className="relative min-h-[85vh] flex items-start pt-4 md:pt-8 overflow-hidden">
          {/* Background Image with Overlay */}
          <div className="absolute inset-0 z-0">
            <img 
              src="/images/hero-bg.jpg" 
              alt="Background" 
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-slate-900/95 via-slate-900/80 to-slate-900/40" />
          </div>

          <div className="container relative z-10 px-4 md:px-6 py-20">
            <div className="max-w-3xl animate-in slide-in-from-bottom-10 duration-1000 fade-in">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 backdrop-blur-sm mb-8">
                <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                <span className="text-sm font-medium text-primary-foreground/90">Soluções Financeiras Inteligentes</span>
              </div>
              
              <h1 className="text-5xl md:text-7xl font-serif font-bold leading-tight mb-6 drop-shadow-lg">
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-emerald-400 to-primary">Credibilidade</span> <span className="text-white">para</span> <br />
                <span className="text-white">seu</span> <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-emerald-400 to-primary">negócio</span>
              </h1>
              
              <p className="text-xl text-slate-300 mb-10 leading-relaxed max-w-2xl">
                Transformamos suas contas a receber em capital de giro imediato. 
                Soluções de securitização de recebíveis que impulsionam o crescimento da sua empresa com segurança e agilidade.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg" 
                  onClick={() => {
                    const element = document.getElementById('contato');
                    if (element) {
                      element.scrollIntoView({ behavior: 'smooth' });
                    }
                  }}
                  className="bg-primary hover:bg-primary/90 text-white text-lg px-8 h-14 rounded-xl shadow-lg shadow-primary/25 transition-all hover:-translate-y-1"
                >
                  Fale com um Especialista
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
                <Button 
                  size="lg" 
                  variant="outline" 
                  onClick={() => {
                    const element = document.getElementById('servicos');
                    if (element) {
                      element.scrollIntoView({ behavior: 'smooth' });
                    }
                  }}
                  className="border-white/20 text-white hover:bg-white/10 text-lg px-8 h-14 rounded-xl backdrop-blur-sm transition-all hover:-translate-y-1"
                >
                  Conheça Nossos Serviços
                </Button>
              </div>
            </div>
          </div>

          {/* Floating Stats Cards - Neomorphism Style */}
          <div className="hidden lg:block absolute right-10 bottom-20 z-20 space-y-6">
            <div className="bg-white/10 backdrop-blur-md border border-white/20 p-6 rounded-2xl shadow-2xl transform hover:scale-105 transition-all duration-300 w-64">
              <div className="flex items-center gap-4 mb-2">
                <div className="p-3 bg-primary/20 rounded-xl">
                  <Users className="w-6 h-6 text-primary-foreground" />
                </div>
                <div>
                  <p className="text-sm text-slate-300">Clientes Ativos</p>
                  <p className="text-2xl font-bold text-white">50+</p>
                </div>
              </div>
            </div>
            <div className="bg-white/10 backdrop-blur-md border border-white/20 p-6 rounded-2xl shadow-2xl transform hover:scale-105 transition-all duration-300 w-64 ml-12">
              <div className="flex items-center gap-4 mb-2">
                <div className="p-3 bg-secondary/20 rounded-xl">
                  <BarChart3 className="w-6 h-6 text-secondary" />
                </div>
                <div>
                  <p className="text-sm text-slate-300">Capital Operacional</p>
                  <p className="text-2xl font-bold text-white">R$ 50M+</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Calculadora de Antecipação */}
        <Calculator />

        {/* Features Section */}
        <section className="py-24 bg-muted/30 relative overflow-hidden" id="sobre">
          <div className="container px-4 md:px-6">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-4">Por que escolher a Lidasec?</h2>
              <p className="text-lg text-muted-foreground">
                Três pilares que sustentam nossa excelência em securitização de recebíveis, garantindo o melhor para o seu negócio.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              {[
                {
                  icon: <TrendingUp className="w-8 h-8 text-primary" />,
                  title: "Recebível Futuro Imediato",
                  desc: "Transforme suas contas a receber em capital de giro imediato com taxas competitivas e processos ágeis."
                },
                {
                  icon: <Users className="w-8 h-8 text-primary" />,
                  title: "Atendimento Personalizado",
                  desc: "Equipe dedicada que entende os desafios únicos do seu negócio e oferece soluções sob medida."
                },
                {
                  icon: <ShieldCheck className="w-8 h-8 text-primary" />,
                  title: "Segurança e Transparência",
                  desc: "Operações claras, seguras e em total conformidade com as regulamentações do setor."
                }
              ].map((feature, idx) => (
                <Card key={idx} className="border-none shadow-lg hover:shadow-xl transition-all duration-300 bg-card group hover:-translate-y-2">
                  <CardContent className="p-8">
                    <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mb-6 group-hover:bg-primary transition-colors duration-300">
                      <div className="group-hover:text-white transition-colors duration-300">
                        {feature.icon}
                      </div>
                    </div>
                    <h3 className="text-xl font-bold mb-3 text-foreground">{feature.title}</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      {feature.desc}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Services Section */}
        <section className="py-24 bg-background" id="servicos">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
              <div className="max-w-2xl">
                <span className="text-primary font-bold tracking-wider uppercase text-sm mb-2 block">Nossas Soluções</span>
                <h2 className="text-3xl md:text-5xl font-serif font-bold text-foreground">
                  Serviços especializados para <br />
                  impulsionar seu crescimento
                </h2>
              </div>
              <Button variant="outline" className="hidden md:flex">Ver todos os serviços</Button>
            </div>

            <div className="grid lg:grid-cols-3 gap-8">
              {/* Service 1 */}
              <div className="group relative overflow-hidden rounded-3xl bg-white shadow-2xl border border-border/50 transition-all hover:shadow-primary/10">
                <div className="aspect-square overflow-hidden">
                  <img 
                    src="/images/service-factoring.jpg" 
                    alt="Factoring Convencional" 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/60 to-transparent opacity-90" />
                <div className="absolute bottom-0 left-0 right-0 p-8 translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                  <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center mb-4 shadow-lg">
                    <BarChart3 className="text-white w-6 h-6" />
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-2">Securitização de Recebíveis</h3>
                  <p className="text-slate-300 mb-6 opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-100">
                    Transformação de recebíveis em títulos negociáveis. Antecipação de até 90% do valor com segurança jurídica.
                  </p>
                  <Button className="w-full bg-white/10 hover:bg-white/20 text-white border-none backdrop-blur-sm">
                    Saiba Mais
                  </Button>
                </div>
              </div>

              {/* Service 2 */}
              <div className="group relative overflow-hidden rounded-3xl bg-white shadow-2xl border border-border/50 transition-all hover:shadow-primary/10">
                <div className="aspect-square overflow-hidden">
                  <img 
                    src="/images/service-fomento.jpg" 
                    alt="Fomento Mercantil" 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/60 to-transparent opacity-90" />
                <div className="absolute bottom-0 left-0 right-0 p-8 translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                  <div className="w-12 h-12 bg-secondary rounded-xl flex items-center justify-center mb-4 shadow-lg">
                    <TrendingUp className="text-secondary-foreground w-6 h-6" />
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-2">Cessão de Crédito</h3>
                  <p className="text-slate-300 mb-6 opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-100">
                    Transferência de créditos com garantia e segurança jurídica. Aprovação em 48 horas.
                  </p>
                  <Button className="w-full bg-white/10 hover:bg-white/20 text-white border-none backdrop-blur-sm">
                    Saiba Mais
                  </Button>
                </div>
              </div>

              {/* Service 3 */}
              <div className="group relative overflow-hidden rounded-3xl bg-white shadow-2xl border border-border/50 transition-all hover:shadow-primary/10">
                <div className="aspect-square overflow-hidden">
                  <img 
                    src="/images/service-export.jpg" 
                    alt="Factoring Exportação" 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/60 to-transparent opacity-90" />
                <div className="absolute bottom-0 left-0 right-0 p-8 translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                  <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center mb-4 shadow-lg">
                    <Globe2 className="text-white w-6 h-6" />
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-2">FIDC - Fundo de Investimento</h3>
                  <p className="text-slate-300 mb-6 opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-100">
                    Estruturação de fundos de investimento em direitos creditórios. Solução completa e regulamentada.
                  </p>
                  <Button className="w-full bg-white/10 hover:bg-white/20 text-white border-none backdrop-blur-sm">
                    Saiba Mais
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* About Section */}
        <section className="py-24 bg-slate-900 text-white relative overflow-hidden">
          <div className="absolute top-0 right-0 w-1/2 h-full bg-primary/5 blur-3xl rounded-full -translate-y-1/2 translate-x-1/4" />
          
          <div className="container px-4 md:px-6 relative z-10">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <div className="relative">
                <div className="relative rounded-3xl overflow-hidden shadow-2xl border border-white/10">
                  <img 
                    src="/images/about-team.jpg" 
                    alt="Equipe Lidasec" 
                    className="w-full object-cover"
                  />
                </div>
                {/* Floating Experience Card */}
                <div className="absolute -bottom-8 -right-8 bg-white p-8 rounded-2xl shadow-xl hidden md:block">
                  <p className="text-5xl font-bold text-primary mb-1">15+</p>
                  <p className="text-slate-600 font-medium">Anos de<br />Experiência</p>
                </div>
              </div>

              <div>
                <span className="text-primary font-bold tracking-wider uppercase text-sm mb-4 block">Sobre a Lidasec</span>
                <h2 className="text-3xl md:text-5xl font-serif font-bold mb-6">
                  Parceiros estratégicos para o seu sucesso financeiro
                </h2>
                <p className="text-slate-300 text-lg mb-8 leading-relaxed">
                  A Lidasec é uma securitizadora especializada em operações de securitização de recebíveis, dedicada a oferecer soluções financeiras inovadoras e seguras para empresas de todos os portes.
                  Nossa missão é ser o parceiro financeiro de confiança que impulsiona o crescimento sustentável dos negócios.
                </p>

                <div className="space-y-4 mb-10">
                  {[
                    "Análise de crédito rápida e eficiente",
                    "Taxas competitivas e transparentes",
                    "Atendimento consultivo e personalizado",
                    "Plataforma digital para gestão de operações"
                  ].map((item, idx) => (
                    <div key={idx} className="flex items-center gap-3">
                      <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
                        <CheckCircle2 className="w-4 h-4 text-primary" />
                      </div>
                      <span className="text-slate-200">{item}</span>
                    </div>
                  ))}
                </div>

                <Button size="lg" className="bg-primary hover:bg-primary/90 text-white px-8 h-12 rounded-xl">
                  Conheça Nossa História
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section className="py-24 bg-muted/30" id="contato">
          <div className="container px-4 md:px-6">
            <div className="grid lg:grid-cols-2 gap-16">
              <div>
                <h2 className="text-3xl md:text-5xl font-serif font-bold text-foreground mb-6">
                  Vamos impulsionar seu negócio juntos?
                </h2>
                <p className="text-lg text-muted-foreground mb-10">
                  Preencha o formulário e nossa equipe de especialistas entrará em contato em até 24 horas para apresentar a melhor solução para sua empresa.
                </p>

                <div className="grid sm:grid-cols-2 gap-6 mb-10">
                  <div className="bg-card p-6 rounded-2xl shadow-sm border border-border">
                    <h4 className="font-bold text-lg mb-2">Atendimento</h4>
                    <p className="text-muted-foreground">(47) 99717-6400</p>
                    <p className="text-muted-foreground">contato@lidasec.com.br</p>
                  </div>
                  <div className="bg-card p-6 rounded-2xl shadow-sm border border-border">
                    <h4 className="font-bold text-lg mb-2">Localização</h4>
                    <p className="text-muted-foreground">Av. Getúlio Vargas, 814</p>
                    <p className="text-muted-foreground">Joinville - SC</p>
                  </div>
                </div>
              </div>

              <Card className="border-none shadow-2xl bg-white">
                <CardContent className="p-8 md:p-10">
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid sm:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-foreground">Nome Completo</label>
                        <Input 
                          placeholder="Seu nome" 
                          value={formData.name}
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                          required
                          className="h-12 bg-muted/30 border-border/50 focus:bg-white transition-colors" 
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-foreground">Telefone</label>
                        <Input 
                          placeholder="(00) 00000-0000" 
                          value={formData.phone}
                          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                          className="h-12 bg-muted/30 border-border/50 focus:bg-white transition-colors" 
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-foreground">Email</label>
                      <Input 
                        type="email" 
                        placeholder="seu@email.com" 
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        required
                        className="h-12 bg-muted/30 border-border/50 focus:bg-white transition-colors" 
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium text-foreground">Como podemos ajudar?</label>
                      <Textarea 
                        placeholder="Descreva sua necessidade..." 
                        value={formData.message}
                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                        required
                        className="min-h-[120px] bg-muted/30 border-border/50 focus:bg-white transition-colors resize-none" 
                      />
                    </div>

                    <Button 
                      type="submit"
                      disabled={contactMutation.isPending}
                      className="w-full h-14 text-lg bg-primary hover:bg-primary/90 text-white shadow-lg shadow-primary/20"
                    >
                      {contactMutation.isPending ? "Enviando..." : "Solicitar Contato"}
                    </Button>
                    
                    <p className="text-xs text-center text-muted-foreground">
                      Seus dados estão seguros conosco. Política de Privacidade.
                    </p>
                  </form>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
