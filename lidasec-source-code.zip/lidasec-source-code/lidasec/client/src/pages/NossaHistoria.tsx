import Footer from "@/components/Footer";
import Header from "@/components/Header";
import { Card, CardContent } from "@/components/ui/card";
import { Eye, HandHeart, Heart, Rocket, Shield, Target, Users } from "lucide-react";

export default function NossaHistoria() {

  const values = [
    {
      icon: <Users className="w-8 h-8" />,
      title: "Relacionamento com Pessoas",
      description: "Valorizamos cada interação humana, construindo conexões genuínas e duradouras com nossos clientes e parceiros."
    },
    {
      icon: <Heart className="w-8 h-8" />,
      title: "Responsabilidade Social",
      description: "Atuamos com consciência do nosso papel na comunidade, contribuindo para o desenvolvimento econômico da região."
    },
    {
      icon: <HandHeart className="w-8 h-8" />,
      title: "Humildade",
      description: "Mantemos os pés no chão, sempre abertos a aprender e evoluir junto com nossos clientes e o mercado."
    },
    {
      icon: <Rocket className="w-8 h-8" />,
      title: "Comprometimento",
      description: "Assumimos cada operação como nossa, dedicando total empenho para entregar os melhores resultados."
    },
    {
      icon: <Shield className="w-8 h-8" />,
      title: "Respeito",
      description: "Tratamos clientes internos e externos com dignidade, ética e consideração em todas as interações."
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="pt-24 md:pt-28">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-primary/10 via-background to-secondary/10 py-20">
          <div className="container px-4 md:px-6">
            <div className="max-w-4xl mx-auto text-center">
              <h1 className="text-4xl md:text-6xl font-serif font-bold text-foreground mb-6">
                Nossa História
              </h1>
              <p className="text-xl md:text-2xl text-primary font-semibold italic">
                "Credibilidade para seu negócio"
              </p>
            </div>
          </div>
        </section>

        {/* História */}
        <section className="py-20">
          <div className="container px-4 md:px-6">
            <div className="max-w-4xl mx-auto">
              <div className="prose prose-lg max-w-none">
                <h2 className="text-3xl font-serif font-bold text-foreground mb-6">Uma Nova Era em Securitização</h2>
                
                <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                  Em <strong>2023</strong>, nasceu em <strong>Joinville - SC</strong> a Lidasec Securitizadora, fruto da visão empreendedora da <strong>família Herdt Schuelter</strong>. Com décadas de experiência no mercado financeiro e profundo conhecimento das necessidades das empresas da região, os fundadores identificaram a oportunidade de criar uma securitizadora moderna, ágil e verdadeiramente comprometida com o sucesso de seus clientes.
                </p>

                <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                  Desde o primeiro dia de operação, a Lidasec nasceu com DNA tecnológico. Implementamos <strong>sistemas ERP integrados</strong> de última geração, garantindo processos automatizados, transparência total nas operações e agilidade incomparável na análise e liberação de crédito. Essa estrutura tecnológica nos permite oferecer uma experiência diferenciada aos nossos clientes.
                </p>

                <h3 className="text-2xl font-serif font-bold text-foreground mt-12 mb-6">Tecnologia a Serviço do Cliente</h3>

                <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                  Nossa plataforma integrada permite que todo o processo de securitização seja realizado de forma rápida e segura. Desde a análise de crédito até a liberação dos recursos, cada etapa é monitorada e otimizada para garantir a melhor experiência possível. Os clientes têm acesso a informações em tempo real sobre suas operações, com total transparência.
                </p>

                <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                  A securitização de recebíveis oferece às empresas uma alternativa inteligente para transformar vendas a prazo em capital imediato. Com a Lidasec, nossos clientes conseguem manter seu fluxo de caixa saudável, investir em crescimento e aproveitar oportunidades de mercado sem comprometer seus limites bancários.
                </p>

                <h3 className="text-2xl font-serif font-bold text-foreground mt-12 mb-6">Credibilidade Construída com Resultados</h3>

                <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                  Nosso slogan <strong>"Credibilidade para seu negócio"</strong> não é apenas uma frase – é o compromisso que assumimos com cada cliente. Entendemos que a confiança se constrói através de ações consistentes: análises justas, taxas competitivas, prazos cumpridos e atendimento humanizado. Cada operação realizada fortalece os laços de parceria que nos unem ao mercado.
                </p>

                <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                  Localizados estrategicamente em Joinville, o maior polo industrial de Santa Catarina, estamos posicionados para atender empresas de diversos segmentos que buscam soluções financeiras inteligentes para impulsionar seu crescimento. Nossa equipe conhece profundamente a realidade do empresário local e está preparada para oferecer soluções sob medida.
                </p>

                <p className="text-lg text-muted-foreground mb-6 leading-relaxed italic border-l-4 border-primary pl-6 bg-primary/5 py-4">
                  "Na Lidasec, transformamos recebíveis futuros em crédito imediato, gerando divisas e proporcionando o crescimento sustentável das empresas. Essa é nossa missão e nosso compromisso diário."
                </p>
              </div>

              {/* Timeline */}
              <div className="mt-16 space-y-8">
                <h3 className="text-2xl font-serif font-bold text-foreground mb-8">Nossa Trajetória</h3>
                
                <div className="relative border-l-2 border-primary/30 pl-8 space-y-12">
                  <div>
                    <div className="absolute -left-3 w-6 h-6 rounded-full bg-primary border-4 border-background" />
                    <div className="text-sm font-bold text-primary mb-2">2023</div>
                    <h4 className="text-lg font-bold text-foreground mb-2">Fundação da Lidasec Securitizadora</h4>
                    <p className="text-muted-foreground">A família Herdt Schuelter funda a Lidasec em Joinville - SC, já como securitizadora moderna com sistemas ERP integrados desde o início.</p>
                  </div>

                  <div>
                    <div className="absolute -left-3 w-6 h-6 rounded-full bg-primary border-4 border-background" />
                    <div className="text-sm font-bold text-primary mb-2">2023</div>
                    <h4 className="text-lg font-bold text-foreground mb-2">Implementação de Sistemas ERP</h4>
                    <p className="text-muted-foreground">Desde a fundação, operamos com sistemas integrados de última geração, garantindo agilidade, transparência e eficiência em todas as operações.</p>
                  </div>

                  <div>
                    <div className="absolute -left-3 w-6 h-6 rounded-full bg-primary border-4 border-background" />
                    <div className="text-sm font-bold text-primary mb-2">2024</div>
                    <h4 className="text-lg font-bold text-foreground mb-2">Consolidação no Mercado</h4>
                    <p className="text-muted-foreground">Expansão da carteira de clientes e fortalecimento da marca como referência em securitização na região de Joinville.</p>
                  </div>

                  <div>
                    <div className="absolute -left-3 w-6 h-6 rounded-full bg-primary border-4 border-background" />
                    <div className="text-sm font-bold text-primary mb-2">Presente</div>
                    <h4 className="text-lg font-bold text-foreground mb-2">Construindo o Futuro</h4>
                    <p className="text-muted-foreground">Continuamos investindo em tecnologia e relacionamentos para ser a securitizadora de referência em Joinville e região.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Missão, Visão */}
        <section className="py-20 bg-muted/30">
          <div className="container px-4 md:px-6">
            <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-8">
              <Card className="border-2 border-primary/20 bg-gradient-to-br from-primary/5 to-transparent">
                <CardContent className="p-8">
                  <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-6">
                    <Target className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="text-2xl font-serif font-bold text-foreground mb-4">Nossa Missão</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Transformar crédito imediato de recebíveis futuros, gerando divisas e proporcionando o crescimento das empresas com segurança, agilidade e transparência.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-2 border-primary/20 bg-gradient-to-br from-primary/5 to-transparent">
                <CardContent className="p-8">
                  <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-6">
                    <Eye className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="text-2xl font-serif font-bold text-foreground mb-4">Nossa Visão</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Ser lembrado pelo cliente como opção na hora de fazer as operações de crédito e ser referência do setor em Joinville e região.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Valores */}
        <section className="py-20">
          <div className="container px-4 md:px-6">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-4">
                Nossos Valores
              </h2>
              <p className="text-lg text-muted-foreground">
                Os princípios que guiam todas as nossas decisões e relacionamentos
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-6 max-w-7xl mx-auto">
              {values.map((value, index) => (
                <Card key={index} className="border-none shadow-lg hover:shadow-xl transition-all duration-300">
                  <CardContent className="p-6 text-center">
                    <div className="w-14 h-14 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-4 text-primary">
                      {value.icon}
                    </div>
                    <h3 className="text-lg font-bold mb-2 text-foreground">{value.title}</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {value.description}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-20 bg-primary text-primary-foreground">
          <div className="container px-4 md:px-6">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-3xl md:text-4xl font-serif font-bold mb-6">
                Faça Parte da Nossa História
              </h2>
              <p className="text-lg opacity-90 mb-8">
                Junte-se às empresas que já descobriram o poder da securitização com a Lidasec. 
                Vamos construir juntos o próximo capítulo do seu sucesso.
              </p>
              <a
                href="/#contato"
                className="inline-flex items-center gap-2 bg-white text-primary px-8 py-4 rounded-lg font-semibold hover:bg-white/90 transition-colors"
              >
                Fale com um Especialista
              </a>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
