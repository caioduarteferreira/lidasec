import { describe, expect, it, beforeAll } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import { upsertUser } from "./db";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAdminContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "admin-user",
    email: "admin@lidasec.com",
    name: "Admin User",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return ctx;
}

function createPublicContext(): TrpcContext {
  const ctx: TrpcContext = {
    user: undefined,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return ctx;
}

describe("Blog Public API", () => {
  it("should get published posts without authentication", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.blog.getPosts({ limit: 10, offset: 0 });

    expect(Array.isArray(result)).toBe(true);
    // All returned posts should be published
    result.forEach((post) => {
      expect(post.status).toBe("published");
    });
  });

  it("should get all categories without authentication", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.blog.getCategories();

    expect(Array.isArray(result)).toBe(true);
  });

  it("should get all tags without authentication", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.blog.getTags();

    expect(Array.isArray(result)).toBe(true);
  });
});

describe("Blog Admin API", () => {
  beforeAll(async () => {
    // Ensure test user exists in database
    await upsertUser({
      id: 1,
      openId: "admin-user",
      email: "admin@lidasec.com",
      name: "Admin User",
      loginMethod: "manus",
      role: "admin",
      lastSignedIn: new Date(),
    });
  });
  it("should allow admin to get all posts including drafts", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.blogAdmin.getAllPosts({ limit: 50, offset: 0 });

    expect(Array.isArray(result)).toBe(true);
    // Should include posts with any status
  });

  it("should allow admin to create a category", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const timestamp = Date.now();
    const category = await caller.blogAdmin.createCategory({
      name: `Test Category ${timestamp}`,
      slug: `test-category-${timestamp}`,
      description: "Test description",
    });

    expect(category).toBeDefined();
    expect(category.name).toBe(`Test Category ${timestamp}`);
    expect(category.slug).toBe(`test-category-${timestamp}`);
  });

  it("should allow admin to create a tag", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const timestamp = Date.now();
    const tag = await caller.blogAdmin.createTag({
      name: `Test Tag ${timestamp}`,
      slug: `test-tag-${timestamp}`,
    });

    expect(tag).toBeDefined();
    expect(tag.name).toBe(`Test Tag ${timestamp}`);
    expect(tag.slug).toBe(`test-tag-${timestamp}`);
  });

  it("should allow admin to create a blog post", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const timestamp = Date.now();
    const post = await caller.blogAdmin.createPost({
      title: `Test Post ${timestamp}`,
      slug: `test-post-${timestamp}`,
      content: "This is a test post content with **markdown** support.",
      excerpt: "Test excerpt",
      status: "draft",
    });

    expect(post).toBeDefined();
    expect(post.title).toBe(`Test Post ${timestamp}`);
    expect(post.slug).toBe(`test-post-${timestamp}`);
    expect(post.status).toBe("draft");
    expect(post.authorId).toBe(ctx.user!.id);
  });

  it("should allow admin to update a blog post", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    // First create a post
    const timestamp = Date.now();
    const createdPost = await caller.blogAdmin.createPost({
      title: `Original Title ${timestamp}`,
      slug: `original-slug-${timestamp}`,
      content: "Original content",
      status: "draft",
    });

    // Then update it
    const updatedPost = await caller.blogAdmin.updatePost({
      id: createdPost.id,
      title: `Updated Title ${timestamp}`,
      status: "published",
    });

    expect(updatedPost).toBeDefined();
    expect(updatedPost!.title).toBe(`Updated Title ${timestamp}`);
    expect(updatedPost!.status).toBe("published");
  });

  it("should allow admin to delete a blog post", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    // First create a post
    const timestamp = Date.now();
    const createdPost = await caller.blogAdmin.createPost({
      title: `Post to Delete ${timestamp}`,
      slug: `post-to-delete-${timestamp}`,
      content: "This post will be deleted",
      status: "draft",
    });

    // Then delete it
    const result = await caller.blogAdmin.deletePost({ id: createdPost.id });

    expect(result.success).toBe(true);
  });
});

describe("Blog Search and Filtering", () => {
  it("should search posts by query", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    // This test assumes there are published posts in the database
    // In a real scenario, you might want to seed test data first
    const result = await caller.blog.searchPosts({ query: "financeiro" });

    expect(Array.isArray(result)).toBe(true);
    // All results should be published
    result.forEach((post) => {
      expect(post.status).toBe("published");
    });
  });
});
