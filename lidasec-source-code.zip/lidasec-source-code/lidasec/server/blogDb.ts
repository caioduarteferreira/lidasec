import { and, desc, eq, like, or, sql } from "drizzle-orm";
import {
  blogCategories,
  blogPosts,
  blogPostTags,
  blogTags,
  type BlogCategory,
  type BlogPost,
  type BlogTag,
  type InsertBlogCategory,
  type InsertBlogPost,
  type InsertBlogTag,
} from "../drizzle/schema";
import { getDb } from "./db";

// ============ Categories ============

export async function getAllCategories(): Promise<BlogCategory[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(blogCategories).orderBy(blogCategories.name);
}

export async function getCategoryBySlug(slug: string): Promise<BlogCategory | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(blogCategories).where(eq(blogCategories.slug, slug)).limit(1);
  return result[0];
}

export async function createCategory(category: InsertBlogCategory): Promise<BlogCategory> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(blogCategories).values(category);
  const inserted = await db.select().from(blogCategories).where(eq(blogCategories.id, Number(result[0].insertId))).limit(1);
  return inserted[0]!;
}

export async function updateCategory(id: number, category: Partial<InsertBlogCategory>): Promise<BlogCategory | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  
  await db.update(blogCategories).set(category).where(eq(blogCategories.id, id));
  const result = await db.select().from(blogCategories).where(eq(blogCategories.id, id)).limit(1);
  return result[0];
}

export async function deleteCategory(id: number): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.delete(blogCategories).where(eq(blogCategories.id, id));
}

// ============ Tags ============

export async function getAllTags(): Promise<BlogTag[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(blogTags).orderBy(blogTags.name);
}

export async function getTagBySlug(slug: string): Promise<BlogTag | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(blogTags).where(eq(blogTags.slug, slug)).limit(1);
  return result[0];
}

export async function createTag(tag: InsertBlogTag): Promise<BlogTag> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(blogTags).values(tag);
  const inserted = await db.select().from(blogTags).where(eq(blogTags.id, Number(result[0].insertId))).limit(1);
  return inserted[0]!;
}

export async function deleteTag(id: number): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.delete(blogTags).where(eq(blogTags.id, id));
}

// ============ Posts ============

export interface BlogPostWithDetails extends BlogPost {
  category?: BlogCategory;
  tags?: BlogTag[];
  authorName?: string;
}

export async function getPublishedPosts(limit = 10, offset = 0): Promise<BlogPostWithDetails[]> {
  const db = await getDb();
  if (!db) return [];
  
  const posts = await db
    .select()
    .from(blogPosts)
    .where(eq(blogPosts.status, "published"))
    .orderBy(desc(blogPosts.publishedAt))
    .limit(limit)
    .offset(offset);
  
  return enrichPostsWithDetails(posts);
}

export async function getAllPosts(limit = 50, offset = 0): Promise<BlogPostWithDetails[]> {
  const db = await getDb();
  if (!db) return [];
  
  const posts = await db
    .select()
    .from(blogPosts)
    .orderBy(desc(blogPosts.createdAt))
    .limit(limit)
    .offset(offset);
  
  return enrichPostsWithDetails(posts);
}

export async function getPostBySlug(slug: string): Promise<BlogPostWithDetails | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(blogPosts).where(eq(blogPosts.slug, slug)).limit(1);
  if (!result[0]) return undefined;
  
  const enriched = await enrichPostsWithDetails([result[0]]);
  return enriched[0];
}

export async function getPostById(id: number): Promise<BlogPostWithDetails | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(blogPosts).where(eq(blogPosts.id, id)).limit(1);
  if (!result[0]) return undefined;
  
  const enriched = await enrichPostsWithDetails([result[0]]);
  return enriched[0];
}

export async function searchPosts(query: string): Promise<BlogPostWithDetails[]> {
  const db = await getDb();
  if (!db) return [];
  
  const posts = await db
    .select()
    .from(blogPosts)
    .where(
      and(
        eq(blogPosts.status, "published"),
        or(
          like(blogPosts.title, `%${query}%`),
          like(blogPosts.content, `%${query}%`),
          like(blogPosts.excerpt, `%${query}%`)
        )
      )
    )
    .orderBy(desc(blogPosts.publishedAt))
    .limit(20);
  
  return enrichPostsWithDetails(posts);
}

export async function getPostsByCategory(categoryId: number, limit = 10): Promise<BlogPostWithDetails[]> {
  const db = await getDb();
  if (!db) return [];
  
  const posts = await db
    .select()
    .from(blogPosts)
    .where(and(eq(blogPosts.categoryId, categoryId), eq(blogPosts.status, "published")))
    .orderBy(desc(blogPosts.publishedAt))
    .limit(limit);
  
  return enrichPostsWithDetails(posts);
}

export async function createPost(post: InsertBlogPost): Promise<BlogPost> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(blogPosts).values(post);
  const inserted = await db.select().from(blogPosts).where(eq(blogPosts.id, Number(result[0].insertId))).limit(1);
  return inserted[0]!;
}

export async function updatePost(id: number, post: Partial<InsertBlogPost>): Promise<BlogPost | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  
  await db.update(blogPosts).set(post).where(eq(blogPosts.id, id));
  const result = await db.select().from(blogPosts).where(eq(blogPosts.id, id)).limit(1);
  return result[0];
}

export async function deletePost(id: number): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.delete(blogPosts).where(eq(blogPosts.id, id));
}

export async function incrementViewCount(id: number): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.update(blogPosts).set({ viewCount: sql`${blogPosts.viewCount} + 1` }).where(eq(blogPosts.id, id));
}

// ============ Post Tags ============

export async function addTagToPost(postId: number, tagId: number): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.insert(blogPostTags).values({ postId, tagId });
}

export async function removeTagFromPost(postId: number, tagId: number): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.delete(blogPostTags).where(and(eq(blogPostTags.postId, postId), eq(blogPostTags.tagId, tagId)));
}

export async function getPostTags(postId: number): Promise<BlogTag[]> {
  const db = await getDb();
  if (!db) return [];
  
  const result = await db
    .select({ tag: blogTags })
    .from(blogPostTags)
    .innerJoin(blogTags, eq(blogPostTags.tagId, blogTags.id))
    .where(eq(blogPostTags.postId, postId));
  
  return result.map((r) => r.tag);
}

export async function setPostTags(postId: number, tagIds: number[]): Promise<void> {
  const db = await getDb();
  if (!db) return;
  
  // Remove all existing tags
  await db.delete(blogPostTags).where(eq(blogPostTags.postId, postId));
  
  // Add new tags
  if (tagIds.length > 0) {
    await db.insert(blogPostTags).values(tagIds.map((tagId) => ({ postId, tagId })));
  }
}

// ============ Helper Functions ============

async function enrichPostsWithDetails(posts: BlogPost[]): Promise<BlogPostWithDetails[]> {
  const db = await getDb();
  if (!db || posts.length === 0) return posts;
  
  const enriched: BlogPostWithDetails[] = [];
  
  for (const post of posts) {
    const enrichedPost: BlogPostWithDetails = { ...post };
    
    // Get category
    if (post.categoryId) {
      const category = await db.select().from(blogCategories).where(eq(blogCategories.id, post.categoryId)).limit(1);
      enrichedPost.category = category[0];
    }
    
    // Get tags
    enrichedPost.tags = await getPostTags(post.id);
    
    enriched.push(enrichedPost);
  }
  
  return enriched;
}
