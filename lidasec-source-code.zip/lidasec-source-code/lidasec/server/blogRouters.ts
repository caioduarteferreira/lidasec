import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import * as blogDb from "./blogDb";

// Admin-only procedure
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
  }
  return next({ ctx });
});

// ============ Public Blog Router ============

export const blogRouter = router({
  // Get published posts (public)
  getPosts: publicProcedure
    .input(
      z.object({
        limit: z.number().min(1).max(50).default(10),
        offset: z.number().min(0).default(0),
      }).optional()
    )
    .query(async ({ input }) => {
      const { limit = 10, offset = 0 } = input || {};
      return blogDb.getPublishedPosts(limit, offset);
    }),

  // Get single post by slug (public)
  getPostBySlug: publicProcedure
    .input(z.object({ slug: z.string() }))
    .query(async ({ input }) => {
      const post = await blogDb.getPostBySlug(input.slug);
      if (!post) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Post not found" });
      }
      
      // Increment view count
      await blogDb.incrementViewCount(post.id);
      
      return post;
    }),

  // Search posts (public)
  searchPosts: publicProcedure
    .input(z.object({ query: z.string().min(1) }))
    .query(async ({ input }) => {
      return blogDb.searchPosts(input.query);
    }),

  // Get posts by category (public)
  getPostsByCategory: publicProcedure
    .input(
      z.object({
        categoryId: z.number(),
        limit: z.number().min(1).max(50).default(10),
      })
    )
    .query(async ({ input }) => {
      return blogDb.getPostsByCategory(input.categoryId, input.limit);
    }),

  // Get all categories (public)
  getCategories: publicProcedure.query(async () => {
    return blogDb.getAllCategories();
  }),

  // Get all tags (public)
  getTags: publicProcedure.query(async () => {
    return blogDb.getAllTags();
  }),
});

// ============ Admin Blog Router ============

export const blogAdminRouter = router({
  // Get all posts (including drafts)
  getAllPosts: adminProcedure
    .input(
      z.object({
        limit: z.number().min(1).max(100).default(50),
        offset: z.number().min(0).default(0),
      }).optional()
    )
    .query(async ({ input }) => {
      const { limit = 50, offset = 0 } = input || {};
      return blogDb.getAllPosts(limit, offset);
    }),

  // Get post by ID
  getPostById: adminProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const post = await blogDb.getPostById(input.id);
      if (!post) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Post not found" });
      }
      return post;
    }),

  // Create post
  createPost: adminProcedure
    .input(
      z.object({
        title: z.string().min(1).max(255),
        slug: z.string().min(1).max(255),
        excerpt: z.string().optional(),
        content: z.string().min(1),
        featuredImage: z.string().optional(),
        categoryId: z.number().optional(),
        status: z.enum(["draft", "published", "archived"]).default("draft"),
        publishedAt: z.date().optional(),
        tagIds: z.array(z.number()).optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const { tagIds, ...postData } = input;
      
      const post = await blogDb.createPost({
        ...postData,
        authorId: ctx.user.id,
      });
      
      // Add tags if provided
      if (tagIds && tagIds.length > 0) {
        await blogDb.setPostTags(post.id, tagIds);
      }
      
      return post;
    }),

  // Update post
  updatePost: adminProcedure
    .input(
      z.object({
        id: z.number(),
        title: z.string().min(1).max(255).optional(),
        slug: z.string().min(1).max(255).optional(),
        excerpt: z.string().optional(),
        content: z.string().min(1).optional(),
        featuredImage: z.string().optional(),
        categoryId: z.number().optional(),
        status: z.enum(["draft", "published", "archived"]).optional(),
        publishedAt: z.date().optional(),
        tagIds: z.array(z.number()).optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, tagIds, ...postData } = input;
      
      const post = await blogDb.updatePost(id, postData);
      if (!post) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Post not found" });
      }
      
      // Update tags if provided
      if (tagIds !== undefined) {
        await blogDb.setPostTags(id, tagIds);
      }
      
      return post;
    }),

  // Delete post
  deletePost: adminProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await blogDb.deletePost(input.id);
      return { success: true };
    }),

  // Create category
  createCategory: adminProcedure
    .input(
      z.object({
        name: z.string().min(1).max(100),
        slug: z.string().min(1).max(100),
        description: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      return blogDb.createCategory(input);
    }),

  // Update category
  updateCategory: adminProcedure
    .input(
      z.object({
        id: z.number(),
        name: z.string().min(1).max(100).optional(),
        slug: z.string().min(1).max(100).optional(),
        description: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, ...categoryData } = input;
      const category = await blogDb.updateCategory(id, categoryData);
      if (!category) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Category not found" });
      }
      return category;
    }),

  // Delete category
  deleteCategory: adminProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await blogDb.deleteCategory(input.id);
      return { success: true };
    }),

  // Create tag
  createTag: adminProcedure
    .input(
      z.object({
        name: z.string().min(1).max(50),
        slug: z.string().min(1).max(50),
      })
    )
    .mutation(async ({ input }) => {
      return blogDb.createTag(input);
    }),

  // Delete tag
  deleteTag: adminProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await blogDb.deleteTag(input.id);
      return { success: true };
    }),
});
