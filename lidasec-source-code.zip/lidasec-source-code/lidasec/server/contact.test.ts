import { describe, expect, it } from "vitest";
import { Resend } from "resend";

describe("Resend Email Integration", () => {
  it("should have valid RESEND_API_KEY configured", () => {
    const apiKey = process.env.RESEND_API_KEY;
    expect(apiKey).toBeDefined();
    expect(apiKey).not.toBe("");
    expect(apiKey?.startsWith("re_")).toBe(true);
  });

  it("should be able to initialize Resend client", () => {
    const resend = new Resend(process.env.RESEND_API_KEY);
    expect(resend).toBeDefined();
    expect(resend.emails).toBeDefined();
  });

  it("should validate API key by attempting to fetch domains", async () => {
    const resend = new Resend(process.env.RESEND_API_KEY);
    
    // Fetch domains is a lightweight read-only API call to validate the key
    const { error } = await resend.domains.list();
    
    // If there's an error, check if it's a permission error (key is valid but restricted)
    // or an authentication error (key is invalid)
    if (error) {
      // "restricted to only send emails" means the key is valid but has limited permissions
      // This is acceptable for our use case (sending contact form emails)
      const isRestrictedKey = error.message?.includes("restricted to only send emails");
      const isInvalidKey = error.message?.includes("Invalid API key") || 
                           error.message?.includes("unauthorized") ||
                           error.message?.includes("Unauthorized");
      
      if (isInvalidKey) {
        throw new Error(`Invalid RESEND_API_KEY: ${error.message}`);
      }
      
      // If it's a restricted key, that's fine - it can still send emails
      if (isRestrictedKey) {
        expect(true).toBe(true); // Key is valid but restricted
        return;
      }
    }
    
    // If we got here without auth error, the key is valid
    expect(true).toBe(true);
  });
});
