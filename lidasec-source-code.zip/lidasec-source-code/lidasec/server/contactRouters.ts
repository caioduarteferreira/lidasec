import { z } from "zod";
import { publicProcedure, router } from "./_core/trpc";
import { Resend } from "resend";

const resend = new Resend(process.env.RESEND_API_KEY);

const contactSchema = z.object({
  name: z.string().min(2, "Nome deve ter pelo menos 2 caracteres"),
  email: z.string().email("Email inválido"),
  phone: z.string().optional(),
  message: z.string().min(10, "Mensagem deve ter pelo menos 10 caracteres"),
});

export const contactRouter = router({
  send: publicProcedure
    .input(contactSchema)
    .mutation(async ({ input }) => {
      try {
        // Enviar email usando Resend
        const { data, error } = await resend.emails.send({
          from: "Lidasec Site <onboarding@resend.dev>",
          to: ["caio@serfac.com.br"],
          replyTo: input.email,
          subject: `Nova mensagem de contato - ${input.name}`,
          html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
              <div style="background: linear-gradient(135deg, #006847 0%, #00a651 100%); padding: 30px; text-align: center;">
                <h1 style="color: white; margin: 0; font-size: 24px;">Nova Mensagem de Contato</h1>
                <p style="color: rgba(255,255,255,0.9); margin: 10px 0 0 0;">Site Lidasec Securitizadora</p>
              </div>
              
              <div style="padding: 30px; background: #f9f9f9;">
                <div style="background: white; border-radius: 8px; padding: 25px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                  <h2 style="color: #006847; margin-top: 0; font-size: 18px;">Dados do Contato</h2>
                  
                  <table style="width: 100%; border-collapse: collapse;">
                    <tr>
                      <td style="padding: 12px 0; border-bottom: 1px solid #eee; color: #666; width: 120px;"><strong>Nome:</strong></td>
                      <td style="padding: 12px 0; border-bottom: 1px solid #eee; color: #333;">${input.name}</td>
                    </tr>
                    <tr>
                      <td style="padding: 12px 0; border-bottom: 1px solid #eee; color: #666;"><strong>Email:</strong></td>
                      <td style="padding: 12px 0; border-bottom: 1px solid #eee; color: #333;">
                        <a href="mailto:${input.email}" style="color: #006847;">${input.email}</a>
                      </td>
                    </tr>
                    <tr>
                      <td style="padding: 12px 0; border-bottom: 1px solid #eee; color: #666;"><strong>Telefone:</strong></td>
                      <td style="padding: 12px 0; border-bottom: 1px solid #eee; color: #333;">${input.phone || "Não informado"}</td>
                    </tr>
                  </table>
                  
                  <h3 style="color: #006847; margin-top: 25px; font-size: 16px;">Mensagem:</h3>
                  <div style="background: #f5f5f5; padding: 15px; border-radius: 6px; color: #333; line-height: 1.6;">
                    ${input.message.replace(/\n/g, "<br>")}
                  </div>
                </div>
                
                <p style="text-align: center; color: #999; font-size: 12px; margin-top: 20px;">
                  Este email foi enviado automaticamente pelo formulário de contato do site Lidasec.
                </p>
              </div>
            </div>
          `,
        });

        if (error) {
          console.error("Erro ao enviar email:", error);
          throw new Error("Falha ao enviar email. Tente novamente.");
        }

        console.log("📧 Email enviado com sucesso:", data?.id);
        
        return {
          success: true,
          message: "Mensagem enviada com sucesso! Entraremos em contato em breve.",
        };
      } catch (err) {
        console.error("Erro no envio de email:", err);
        throw new Error("Erro ao enviar mensagem. Por favor, tente novamente ou entre em contato pelo WhatsApp.");
      }
    }),
});
